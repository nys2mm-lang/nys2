NY Shell Room Cloud Sync 버전

이 버전은 기존 localStorage 저장을 Netlify Blobs에 동기화해서
휴대폰에서 편집한 내용이 컴퓨터/다른 사람에게도 보이게 하는 구조입니다.

폴더 구조:
- index.html
- netlify.toml
- package.json
- netlify/functions/site-state.mjs

Netlify 설정:
1. 이 ZIP을 풀어서 폴더째 Netlify에 업로드하거나 GitHub로 배포하세요.
2. Netlify Site settings > Environment variables 에서 추가:
   SITE_PASSWORD = ribbon
3. 배포 후 사이트에서 편집모드 비밀번호 ribbon을 입력하면,
   이후 저장되는 localStorage 데이터가 서버에 동기화됩니다.

주의:
- 단일 HTML만 Netlify Drop에 올리면 서버 저장이 안 됩니다.
- 반드시 netlify/functions 폴더가 포함된 프로젝트 전체를 배포해야 합니다.
